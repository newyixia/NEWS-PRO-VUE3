import { IDetailState, INewsInfo } from "@/typings";

const state: IDetailState = {
  currentNews: <INewsInfo>{}
}

export default state;