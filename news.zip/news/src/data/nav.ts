import { INavBar } from "@/typings";

const navData: INavBar[] = [
  {
    type: 'top',
    title: '头条'
  },
  {
    type: 'shehui',
    title: '社会'
  },
  {
    type: 'guonei',
    title: '国内'
  },
  {
    type: 'guoji',
    title: '国际'
  },
  {
    type: 'yule',
    title: '娱乐'
  },
  {
    type: 'tiyu',
    title: '体育'
  },
  {
    type: 'junshi',
    title: '军事'
  },
  {
    type: 'keji',
    title: '科技'
  },
  {
    type: 'caijing',
    title: '财经'
  },
  {
    type: 'shishang',
    title: '时尚'
  },
]

export default navData;