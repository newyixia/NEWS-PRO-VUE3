<template>
  <div class="no-more">没有更多数据了</div>
</template>

<script lang="ts">
export default {
  name: 'NoMore'
}
</script>

<style lang="scss" scoped>
  .no-more {
    height: .38rem;
    line-height: .38rem;
    text-align: center;
    font-size: .14rem;
    color: #999;
  }
</style>