// 设置新闻数据
const SET_NEWS_LIST: string = 'SET_NEWS_LIST';
// 设置loading状态
const SET_LOADING: string = 'SET_LOADING';
// 设置当前新闻类型
const SET_CURRENT_TYPE: string= 'SET_CURRENT_TYPE'

export {
  SET_NEWS_LIST,
  SET_LOADING,
  SET_CURRENT_TYPE
}