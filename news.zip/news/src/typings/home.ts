// 导航数据的类型定义
interface INavBar {
  type: string,
  title: string
}

export {
  INavBar
}