<template>
  <div class="loading">正在加载中...</div>
</template>

<script lang="ts">
export default {
  name: 'Loading'
}
</script>

<style lang="scss" scoped>
  .loading {
    height: .38rem;
    line-height: .38rem;
    text-align: center;
    font-size: .14rem;
    color: #999;
  }
</style>