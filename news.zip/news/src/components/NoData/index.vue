<template>
  <div class="no-data">
    - 没有收藏数据 -
  </div>
</template>

<script lang="ts">
export default {

}
</script>

<style lang="scss" scoped>
  .no-data {
    display: flex;
    height: 100%;
    justify-content: center;
    align-items: center;
    font-size: .16rem;
    color: #999;
  }
</style>